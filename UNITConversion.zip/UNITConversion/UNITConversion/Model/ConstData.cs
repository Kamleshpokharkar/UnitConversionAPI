﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace UNITConversion.Model
{
    public class ConstData
    {
        public string type { get; set; }
        public string unit { get; set; }
        public double amount { get; set; }
    }
}
