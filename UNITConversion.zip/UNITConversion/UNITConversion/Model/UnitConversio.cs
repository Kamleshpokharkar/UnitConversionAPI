﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using UnitsNet;
using UnitsNet.Units;

namespace UNITConversion.Model
{
    public class UnitConversio
    {
        #region :: Function to converunit value Matric To Imperial
        public IEnumerable<ConversionRequest> MatricToImperialConversion( List<ConversionRequest> conversionRequests)
        {
            try
            {
                foreach (var v in conversionRequests)
                {
                    Length meter = Length.FromMeters(v.Unit);
                    double yards = meter.Yards;
                    double feet = meter.Feet;
                    double inches = meter.Inches;
                    double mile = meter.Miles;
                    Temperature temperature = Temperature.FromDegreesFahrenheit(v.Unit);
                    double fahrenheit = temperature.DegreesFahrenheit;
                    v.Result = "yards: " + yards + ", feet: " + feet + "inches: " + inches + ", mile: " + mile+ ", fahrenheit: "+fahrenheit;
                    v.Type = "Imperial";
                   
                }
            }
            catch (Exception)
            {

                throw;
            }
        
            return conversionRequests;
        }
        #endregion
        #region :: Function to converunit value Imperial To Matric
        public IEnumerable<ConversionRequest> ImperialToMatricConversion(List<ConversionRequest> conversionRequests)
        {
            try
            {
                foreach (var v in conversionRequests)
                {
                    Length Feet = Length.FromFeet(v.Unit);
                    double meter = Feet.Meters;
                    double centimeter = Feet.Centimeters;
                    double kilometer = Feet.Kilometers;
                    double milimeter = Feet.Millimeters;

                    Temperature temperature = Temperature.FromDegreesCelsius(v.Unit);
                    double celsius = temperature.DegreesCelsius;

                    v.Result = "meter: " + meter + ", centimeter: " + centimeter + "kilometer: " + kilometer + ", milimeter: " + milimeter+ ", celsius:"+celsius;
                    v.Type = "Metric";
                }
              
            }
            catch (Exception)
            {

                throw;
            }
            return conversionRequests;
        }
        #endregion
    }
}
