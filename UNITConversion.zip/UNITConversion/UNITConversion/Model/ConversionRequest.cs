﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace UNITConversion.Model
{
    public class ConversionRequest
    {
        public double Unit { get; set; }
     
        public string Result { get; set; }
        public string Type { get; set; }

    }
}
