﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace UNITConversion.Model
{
    public class testDb
    {
      public  string Metric = "{\"ConversionRequest\":[{\"Unit\":2,\"Result\":\"\",\"Type\":\"Metric\"},{\"Unit\":3,\"Result\":\"\",\"Type\":\"Metric\"},{\"Unit\":4,\"Result\":\"\",\"Type\":\"Metric\"},{\"Unit\":5,\"Result\":\"\",\"Type\":\"Metric\"}]}";
        public string Imperial = "{\"ConversionRequest\":[{\"Unit\":2,\"Result\":\"\",\"Type\":\"Imperial\"},{\"Unit\":3,\"Result\":\"\",\"Type\":\"Imperial\"},{\"Unit\":4,\"Result\":\"\",\"Type\":\"Imperial\"},{\"Unit\":5,\"Result\":\"\",\"Type\":\"Imperial\"}]}";
    }
}
