﻿
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;

using UNITConversion.Model;

namespace UNITConversion.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class TestAPIController : ControllerBase
    {
        #region :: API function to return unit conversion value (Metric & Imperail)
        [HttpGet]
        public List<ConversionRequest> Convert()
        {
            try
            {
                UnitConversio unitConversio = new UnitConversio();
                List<ConversionRequest> metricToImperail = new List<ConversionRequest>();
                metricToImperail.Add(new ConversionRequest { Type = "Metric", Unit = 2 });
                metricToImperail.Add(new ConversionRequest { Type = "Metric", Unit = 3 });
                metricToImperail.Add(new ConversionRequest { Type = "Metric", Unit = 4 });
                metricToImperail.Add(new ConversionRequest { Type = "Metric", Unit = 5 });

                metricToImperail = unitConversio.MatricToImperialConversion(metricToImperail).ToList();

                List<ConversionRequest> imperailToMetric = new List<ConversionRequest>();
                metricToImperail.Add(new ConversionRequest { Type = "Imperail", Unit = 2 });
                metricToImperail.Add(new ConversionRequest { Type = "Imperail", Unit = 3 });
                metricToImperail.Add(new ConversionRequest { Type = "Imperail", Unit = 4 });
                metricToImperail.Add(new ConversionRequest { Type = "Imperail", Unit = 5 });

                metricToImperail = unitConversio.ImperialToMatricConversion(metricToImperail).ToList();

                return metricToImperail;
            }
            catch (Exception)
            {

                throw;
            }
           
        }
        #endregion

    }
}
